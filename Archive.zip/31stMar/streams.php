<HTML>
<HEAD>
  <TITLE>HOME-Team SASAS</TITLE>
</HEAD>

<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<BODY>

<!-- FIXED MENU BAR ON TOP-->

<style>
body {margin:0;}

.navbar {
  overflow: hidden;
  background-color: #333;
  position: fixed;
  top: 0;
  width: 100%;
  z-index: 500;
}

.navbar a {
  float: left;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 48px;
  text-decoration: none;
  font-family: Arial;
  font-size: 17px;
  z-index: 500;
}

.navbar a:hover {
  background: #ddd;
  color: black;
}

</style>
</head>
<body>

<div class="navbar" style="position:fixed;">
  <a href="index.html">HOME</a>
  <a href="aboutus.html">ABOUT US</a>
  <a href="ourproject.html">OUR PROJECT</a>
  <a href="companylogin.html">COMPANY LOGIN</a>
  <a href="#contact">CONTACT US</a>

</div>

<!-- LOGOS-IMAGE -->

<IMG style="position:fixed; top:80px; left:50px; width:140px; height:145px;" src="Nit_Raipur_logo.jpg">
<IMG style="position:fixed; top:43px; left:1150px; width:280px; height:215px;" src="SIH_2018_logo.jpg">

<!-- TEAM NAME and PROBLEM-->


<H1 style="position:fixed; top:90px; left:600px; font-family:Arial; font-style: bold;">TEAM SASAS</H1>
<p style="position:fixed; top:140px; left:350px; font-family:Arial; font-size:20px; text-align:center;">Prediction of Admission and Jobs in Engineering, Management and Pharmacy<br>with respect to Demographic Location</p>



<!-- TEAM AND PROBLEM DETAILS -->

<p style="position:fixed; top:230px; left:45px; font-family:Arial; font-size:16px; text-align:left; z-index: 500;">Team id: 16754<br>Problem Statement code: #GGJ15</p>
<p style="position:fixed; top:230px; left:1100px; font-family:Arial; font-size:16px; text-align:left; z-index: 500;">National Institute of Technology Raipur<br>Ministry/State: Government of Gujarat</p>


<!-- DROPDOWN MENU -->

<?php

session_start();

$loc = $_SESSION['location'];
$fos = $_SESSION['fos'];
$_SESSION['streams'] = $_POST['streams'];
$streams = $_SESSION['streams'];

echo "<p style='position:fixed; font-family:Arial; margin-left: 200px; margin-top: 390px'>$loc</p>";
echo "<p style='position:fixed; font-family:Arial; margin-left: 200px; margin-top: 460px'>$fos</p>";
echo "<p style='position:fixed; font-family:Arial; margin-left: 200px; margin-top: 530px'>$streams</p>";

$location1 = 'Data/'.$loc.'/'.$fos.'/'.$streams.'/1.jpg';
$location2 = 'Data/'.$loc.'/'.$fos.'/'.$streams.'/2.jpg';
$location3 = 'Data/'.$loc.'/'.$fos.'/'.$streams.'/3.jpg';
$location4 = 'Data/'.$loc.'/'.$fos.'/'.$streams.'/4.jpg';

echo "<img src=$location1 style='margin-top: 320px; margin-left: 550px;width:320px; height:245px;'>";
echo "<img src=$location2 style='margin-top: -245px; margin-left: 900px;width:320px; height:245px;'>";
echo "<img src=$location3 style='margin-top: 100px; margin-left: 550px;width:320px; height:245px;'>";
echo "<img src=$location4 style='margin-top: -245px; margin-left: 900px;width:320px; height:245px;'>";

?>


<H3 style="position:fixed; font-family:Arial; margin-left: 200px; margin-top: -550px">Location</H3>
<H3 style="position:fixed; font-family:Arial; margin-left: 200px; margin-top: -480px">Field of Study</H3>
<H3 style="position:fixed; font-family:Arial; margin-left: 200px; margin-top: -410px">Stream</H3>

<form action='addm.php' method='POST' style='margin-top: -340px; margin-left: 150px; position: fixed;'>
<input type='submit' value="Predict Admission" style='background-color: #434343;
    position: fixed;
    border: none;
    color: white;
    padding: 13px 28px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 18px;
    box-shadow: 0 12px 16px 0 rgba(0,0,0,0.24), 0 17px 50px 0 rgba(0,0,0,0.19);
    font-family: Arial;'>
  </form>


<style>
.footer {
   height:100px;
   left: 0;
   bottom: 0;
   width: 100%;
   background-color: #BDBDBD;
   color: white;
   text-align: center;
   margin-top: 100px;
}
</style>



<div class="footer">
</div>

  <IMG style="position:absolute; top:1040px; left:930px; width:100px; height:50px" src="MHRD_logo.jpg">
  <IMG style="position:absolute; top:1040px; left:1050px; width:80px; height:50px" src="aicte-logo.jpg">
  <IMG style="position:absolute; top:1040px; left:1150px; width:70px; height:50px" src="mygov_logo.jpg">

<p style="position:absolute; top:1000px; left:35px; font-family:Arial; font-size:18px; text-align:left;">Contact Us at:<br>idea@i4c.co.in<br>i4c.idea@gmail.com</p> 


</BODY>
</HTML>