<HTML>
<HEAD>
	<TITLE>HOME-Team SASAS</TITLE>
</HEAD>

<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<BODY>

<!-- FIXED MENU BAR ON TOP-->

<style>
body {margin:0;}

.navbar {
  overflow: hidden;
  background-color: #333;
  position: fixed;
  top: 0;
  width: 100%;
  z-index: 500;
}

.navbar a {
  float: left;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 48px;
  text-decoration: none;
  font-family: Arial;
  font-size: 17px;
  z-index: 500;
}

.navbar a:hover {
  background: #ddd;
  color: black;
}

</style>
</head>
<body>

<div class="navbar" style="position:fixed;">
  <a href="index.html">HOME</a>
  <a href="aboutus.html">ABOUT US</a>
  <a href="ourproject.html">OUR PROJECT</a>
  <a href="companylogin.html">COMPANY LOGIN</a>
  <a href="#contact">CONTACT US</a>

</div>

<!-- LOGOS-IMAGE -->

<IMG style="position:fixed; top:80px; left:50px; width:140px; height:145px;" src="Nit_Raipur_logo.jpg">
<IMG style="position:fixed; top:43px; left:1150px; width:280px; height:215px;" src="SIH_2018_logo.jpg">

<!-- TEAM NAME and PROBLEM-->


<H2 style="position:fixed; top:90px; left:600px; font-family:Arial; font-style: bold;">TEAM SASAS</H2>
<p style="position:fixed; top:140px; left:350px; font-family:Arial; font-size:22px; text-align:center;">Prediction of Admission and Jobs in Engineering, Management and Pharmacy<br>with respect to Demographic Location</p>



<!-- TEAM AND PROBLEM DETAILS -->

<p style="position:fixed; top:230px; left:45px; font-family:Arial; font-size:16px; text-align:left; z-index: 500;">Team id: 16754<br>Problem Statement code: #GGJ15</p>
<p style="position:fixed; top:230px; left:1100px; font-family:Arial; font-size:16px; text-align:left; z-index: 500;">National Institute of Technology Raipur<br>Ministry/State: Government of Gujarat</p>


<!-- DROPDOWN MENU -->

<H3 style="position:fixed; font-family:Arial; margin-left: 200px; margin-top: -400px">Location</H3>
<H3 style="position:absolute; font-family:Arial; margin-left: 200px; margin-top: -280px">Field of Study</H3>

<?php

session_start();

$loc = $_POST['location'];
$fos = $_POST['fos'];

echo "<p style='position:absolute; font-size: 15pt; font-family:Arial; margin-left: 200px; margin-top: -350px'>$loc</p>";
echo "<p style='position:absolute; font-size: 15pt; font-family:Arial; margin-left: 200px; margin-top: -240px'>$fos</p>";

    $dbhost = "localhost";
    $dbuser = "root";
    $dbpass = "";
    $dbname = "sih18_companylogin";
    $mysqli = new mysqli($dbhost, $dbuser, $dbpass, $dbname);
 
// Check connection
if($mysqli === false){
    die("ERROR: Could not connect. " . $mysqli->connect_error);
}
 
// Attempt select query execution
$sql = "SELECT * FROM data WHERE field='$fos' AND state='$loc'";
if($result = $mysqli->query($sql)){
    if($result->num_rows > 0){
        echo "<table style='position: absolute; margin-left: 500px; margin-top: -450px; border-spacing: 20px;'>";
            echo "<tr>";
                echo "<th>Job Title</th>";
                echo "<th>Location</th>";
                echo "<th>Salary</th>";
                echo "<th>Company</th>";
                echo "<th>Field</th>";
                echo "<th>State</th>";
            echo "</tr>";
        while($row = $result->fetch_array()){
            echo "<tr>";
                echo "<td>" . $row['jobtitle'] . "</td>";
                echo "<td>" . $row['location'] . "</td>";
                echo "<td>" . $row['salary'] . "</td>";
                echo "<td>" . $row['company'] . "</td>";
                echo "<td>" . $row['field'] . "</td>";
                echo "<td>" . $row['state'] . "</td>";
            echo "</tr>";
        }
        echo "</table>";
        // Free result set
        $result->free();
    } else{
        echo "<p style='position: absolute; margin-left: 600px; margin-top: -400px;'>No records matching your query were found.</p>";
    }
} else{
    echo "ERROR: Could not able to execute $sql. " . $mysqli->error;
}
 
// Close connection
$mysqli->close();



?>

<style>
.footer {
   height:100px;
   left: 0;
   bottom: 0;
   width: 100%;
   background-color: #BDBDBD;
   color: white;
   text-align: center;
   margin-top: 770px;
}
</style>



<div class="footer">
</div>

  <IMG style="position:absolute; top:780px; left:930px; width:100px; height:50px" src="MHRD_logo.jpg">
  <IMG style="position:absolute; top:780px; left:1050px; width:80px; height:50px" src="aicte-logo.jpg">
  <IMG style="position:absolute; top:780px; left:1150px; width:70px; height:50px" src="mygov_logo.jpg">

<p style="position:absolute; top:760px; left:35px; font-family:Arial; font-size:18px; text-align:left;">Contact Us at:<br>idea@i4c.co.in<br>i4c.idea@gmail.com</p> 

</BODY>
</HTML>